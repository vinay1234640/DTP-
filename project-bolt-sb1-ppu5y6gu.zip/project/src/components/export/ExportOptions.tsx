import React, { useState } from 'react';
import { useDocumentContext } from '../../context/DocumentContext';
import { FileText, Download, FileType, Settings, Check } from 'lucide-react';

type ExportFormat = 'docx' | 'pdf';

export const ExportOptions: React.FC = () => {
  const { documentContent, documentStyle } = useDocumentContext();
  const [exportFormat, setExportFormat] = useState<ExportFormat>('docx');
  const [exportInProgress, setExportInProgress] = useState(false);

  const handleExport = () => {
    // Simulate export process
    setExportInProgress(true);
    setTimeout(() => {
      setExportInProgress(false);
      // In a real app, this would trigger the actual file download
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-800">Export Document</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div 
          className={`p-4 border rounded-lg cursor-pointer transition-colors ${
            exportFormat === 'docx' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
          }`}
          onClick={() => setExportFormat('docx')}
        >
          <div className="flex items-center mb-2">
            <FileText className="h-6 w-6 text-blue-600 mr-2" />
            <h3 className="font-medium">Microsoft Word</h3>
            {exportFormat === 'docx' && <Check className="h-4 w-4 text-blue-600 ml-auto" />}
          </div>
          <p className="text-sm text-gray-600">Export as a fully editable .docx file compatible with Microsoft Word.</p>
        </div>
        
        <div 
          className={`p-4 border rounded-lg cursor-pointer transition-colors ${
            exportFormat === 'pdf' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
          }`}
          onClick={() => setExportFormat('pdf')}
        >
          <div className="flex items-center mb-2">
            <FileType className="h-6 w-6 text-red-600 mr-2" />
            <h3 className="font-medium">PDF Document</h3>
            {exportFormat === 'pdf' && <Check className="h-4 w-4 text-blue-600 ml-auto" />}
          </div>
          <p className="text-sm text-gray-600">Export as a PDF document for reliable viewing on any device.</p>
        </div>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center mb-3">
          <Settings className="h-5 w-5 text-gray-600 mr-2" />
          <h3 className="font-medium">Export Settings</h3>
        </div>
        
        <div className="space-y-3">
          <div>
            <label className="flex items-center">
              <input type="checkbox" className="rounded text-blue-600" defaultChecked />
              <span className="ml-2 text-sm text-gray-700">Include document metadata</span>
            </label>
          </div>
          
          <div>
            <label className="flex items-center">
              <input type="checkbox" className="rounded text-blue-600" defaultChecked />
              <span className="ml-2 text-sm text-gray-700">Optimize images for smaller file size</span>
            </label>
          </div>
          
          {exportFormat === 'pdf' && (
            <>
              <div>
                <label className="block text-sm text-gray-600 mb-1">PDF Quality</label>
                <select className="w-full border rounded-md p-2 text-sm">
                  <option>High (Print Quality)</option>
                  <option selected>Medium (Standard)</option>
                  <option>Low (Smaller File Size)</option>
                </select>
              </div>
              
              <div>
                <label className="flex items-center">
                  <input type="checkbox" className="rounded text-blue-600" />
                  <span className="ml-2 text-sm text-gray-700">Password protect PDF</span>
                </label>
              </div>
            </>
          )}
          
          {exportFormat === 'docx' && (
            <>
              <div>
                <label className="block text-sm text-gray-600 mb-1">Word Format</label>
                <select className="w-full border rounded-md p-2 text-sm">
                  <option>Word 2019/365 (.docx)</option>
                  <option>Word 2007-2016 (.docx)</option>
                  <option>Word 97-2003 (.doc)</option>
                </select>
              </div>
              
              <div>
                <label className="flex items-center">
                  <input type="checkbox" className="rounded text-blue-600" defaultChecked />
                  <span className="ml-2 text-sm text-gray-700">Include editable equations</span>
                </label>
              </div>
            </>
          )}
        </div>
      </div>
      
      <button 
        className={`w-full flex items-center justify-center py-3 rounded-md transition-colors ${
          documentContent 
            ? 'bg-blue-600 hover:bg-blue-700 text-white' 
            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
        }`}
        disabled={!documentContent || exportInProgress}
        onClick={handleExport}
      >
        {exportInProgress ? (
          <>
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
            Processing...
          </>
        ) : (
          <>
            <Download className="h-5 w-5 mr-2" />
            Export as {exportFormat.toUpperCase()}
          </>
        )}
      </button>
    </div>
  );
};