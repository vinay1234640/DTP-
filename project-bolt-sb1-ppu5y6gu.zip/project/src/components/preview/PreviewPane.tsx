import React from 'react';
import { useDocumentContext } from '../../context/DocumentContext';
import { Eye, Edit, Copy } from 'lucide-react';

export const PreviewPane: React.FC = () => {
  const { documentContent, documentStyle, isEditing, setIsEditing } = useDocumentContext();
  
  const toggleEditMode = () => {
    setIsEditing(!isEditing);
  };
  
  const handleEditChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    // In a real app, this would update the document content
  };
  
  const copyContent = () => {
    navigator.clipboard.writeText(documentContent);
    // Would show a toast notification in a real app
  };

  // Simple markdown-like rendering (in a real app would use a proper markdown renderer)
  const renderContent = () => {
    if (!documentContent) {
      return <p className="text-gray-400 italic">No content to preview yet. Upload a document or enter text to see it here.</p>;
    }
    
    // Very basic rendering for demonstration
    const lines = documentContent.split('\n');
    return lines.map((line, index) => {
      // Heading
      if (line.startsWith('# ')) {
        return (
          <h1 
            key={index} 
            className="text-2xl font-semibold mb-3"
            style={{ color: documentStyle.headingColor, fontWeight: documentStyle.headingWeight }}
          >
            {line.substring(2)}
          </h1>
        );
      }
      
      // Subheading
      if (line.startsWith('## ')) {
        return (
          <h2 
            key={index} 
            className="text-xl font-semibold mb-2"
            style={{ color: documentStyle.headingColor, fontWeight: documentStyle.headingWeight }}
          >
            {line.substring(3)}
          </h2>
        );
      }
      
      // List item
      if (line.startsWith('* ')) {
        return (
          <li 
            key={index} 
            className="ml-5 mb-1"
            style={{ color: documentStyle.textColor }}
          >
            {line.substring(2)}
          </li>
        );
      }
      
      // Blockquote
      if (line.startsWith('> ')) {
        return (
          <blockquote 
            key={index} 
            className="border-l-4 border-gray-300 pl-3 italic my-3"
            style={{ color: documentStyle.textColor }}
          >
            {line.substring(2)}
          </blockquote>
        );
      }
      
      // Empty line
      if (line.trim() === '') {
        return <div key={index} className="h-4"></div>;
      }
      
      // Regular paragraph
      return (
        <p 
          key={index} 
          className="mb-2"
          style={{ 
            color: documentStyle.textColor,
            fontFamily: documentStyle.fontFamily,
            lineHeight: documentStyle.lineHeight,
            fontSize: documentStyle.fontSize === '10pt' ? '0.875rem' : 
                    documentStyle.fontSize === '11pt' ? '0.9375rem' : 
                    documentStyle.fontSize === '12pt' ? '1rem' : 
                    documentStyle.fontSize === '14pt' ? '1.125rem' : '1.25rem'
          }}
        >
          {line}
        </p>
      );
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-800">Document Preview</h2>
        <div className="flex space-x-2">
          <button 
            className="p-1 text-gray-500 hover:text-blue-600 transition-colors"
            onClick={toggleEditMode}
            title={isEditing ? "View mode" : "Edit mode"}
          >
            {isEditing ? <Eye className="h-5 w-5" /> : <Edit className="h-5 w-5" />}
          </button>
          <button 
            className="p-1 text-gray-500 hover:text-blue-600 transition-colors"
            onClick={copyContent}
            title="Copy content"
          >
            <Copy className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      <div className="border rounded-lg p-6 min-h-[400px] bg-white">
        {isEditing ? (
          <textarea
            className="w-full h-full min-h-[400px] p-0 border-0 focus:ring-0 focus:outline-none resize-none"
            value={documentContent}
            onChange={handleEditChange}
            placeholder="Edit your document content here..."
          ></textarea>
        ) : (
          <div className="document-preview">
            {renderContent()}
          </div>
        )}
      </div>
      
      <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600">
        <p className="flex items-center">
          <Eye className="h-4 w-4 mr-1" />
          This is a preview of how your document will appear when exported. Any changes to formatting will be reflected here.
        </p>
      </div>
    </div>
  );
};