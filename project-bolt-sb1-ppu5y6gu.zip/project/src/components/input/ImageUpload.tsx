import React, { useState } from 'react';
import { Upload, X, Image } from 'lucide-react';
import { useDocumentContext } from '../../context/DocumentContext';

export const ImageUpload: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const { processContent } = useDocumentContext();

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    // Only process image files
    if (!file.type.match('image.*')) {
      alert('Please select an image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPreviewUrl(reader.result);
        // In a real app, we would send this to the OCR service
        processContent('Image has been uploaded and is being processed for text extraction...');
      }
    };
    reader.readAsDataURL(file);
  };

  const clearPreview = () => {
    setPreviewUrl(null);
  };

  return (
    <div className="space-y-4">
      {!previewUrl ? (
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-2">Drag and drop an image here, or</p>
          <label className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md cursor-pointer transition-colors inline-block">
            Browse Files
            <input type="file" className="hidden" accept="image/*" onChange={handleFileInput} />
          </label>
          <p className="text-gray-500 text-sm mt-4">Supported formats: JPG, PNG, GIF</p>
        </div>
      ) : (
        <div className="relative">
          <button
            className="absolute right-2 top-2 bg-red-600 text-white p-1 rounded-full hover:bg-red-700 transition-colors"
            onClick={clearPreview}
          >
            <X className="h-4 w-4" />
          </button>
          <div className="rounded-lg overflow-hidden border">
            <img src={previewUrl} alt="Preview" className="w-full h-auto max-h-64 object-contain" />
          </div>
        </div>
      )}
      
      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
          <Image className="h-4 w-4 mr-1" />
          Image Processing Options
        </h3>
        <div className="space-y-2">
          <label className="flex items-center">
            <input type="checkbox" className="rounded text-blue-600" defaultChecked />
            <span className="ml-2 text-sm text-gray-700">Enhance OCR accuracy</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" className="rounded text-blue-600" defaultChecked />
            <span className="ml-2 text-sm text-gray-700">Detect and extract equations</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" className="rounded text-blue-600" defaultChecked />
            <span className="ml-2 text-sm text-gray-700">Preserve image diagrams</span>
          </label>
        </div>
      </div>
    </div>
  );
};