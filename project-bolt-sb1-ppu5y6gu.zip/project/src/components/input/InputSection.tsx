import React, { useState } from 'react';
import { useDocumentContext } from '../../context/DocumentContext';
import { ImageUpload } from './ImageUpload';
import { PdfUpload } from './PdfUpload';
import { TextInput } from './TextInput';
import { FileImage, FileText, Type, Camera, Download } from 'lucide-react';

type InputType = 'image' | 'pdf' | 'text' | 'camera';

export const InputSection: React.FC = () => {
  const [activeInput, setActiveInput] = useState<InputType>('image');
  const { processContent } = useDocumentContext();

  const handleDemo = () => {
    processContent('# Sample Extracted Document\n\nThis is a demonstration of the text extraction capabilities. The platform can extract plain text, equations, and diagrams from various sources.\n\n## Key Features\n\n* Optical Character Recognition (OCR)\n* Math Equation Recognition\n* Diagram Extraction\n* Multiple Input Sources\n\n> The quality of the extracted content depends on the clarity of the original document.');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-800">Document Input</h2>
      
      <div className="flex justify-between border-b">
        <button
          className={`px-4 py-2 flex flex-col items-center ${activeInput === 'image' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
          onClick={() => setActiveInput('image')}
        >
          <FileImage className="h-5 w-5 mb-1" />
          <span className="text-sm">Image</span>
        </button>
        <button
          className={`px-4 py-2 flex flex-col items-center ${activeInput === 'pdf' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
          onClick={() => setActiveInput('pdf')}
        >
          <FileText className="h-5 w-5 mb-1" />
          <span className="text-sm">PDF</span>
        </button>
        <button
          className={`px-4 py-2 flex flex-col items-center ${activeInput === 'text' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
          onClick={() => setActiveInput('text')}
        >
          <Type className="h-5 w-5 mb-1" />
          <span className="text-sm">Text</span>
        </button>
        <button
          className={`px-4 py-2 flex flex-col items-center ${activeInput === 'camera' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
          onClick={() => setActiveInput('camera')}
        >
          <Camera className="h-5 w-5 mb-1" />
          <span className="text-sm">Camera</span>
        </button>
      </div>

      <div className="py-4">
        {activeInput === 'image' && <ImageUpload />}
        {activeInput === 'pdf' && <PdfUpload />}
        {activeInput === 'text' && <TextInput />}
        {activeInput === 'camera' && (
          <div className="text-center py-8">
            <Camera className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">Access your camera to scan documents</p>
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors">
              Access Camera
            </button>
          </div>
        )}
      </div>
      
      <div className="flex justify-between pt-4 border-t">
        <button 
          onClick={handleDemo}
          className="text-blue-600 hover:text-blue-700 text-sm flex items-center"
        >
          <Download className="h-4 w-4 mr-1" />
          Load Demo Content
        </button>
        
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors">
          Extract Content
        </button>
      </div>
    </div>
  );
};