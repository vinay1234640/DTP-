import React, { useState } from 'react';
import { FileText, Upload, X, Layers } from 'lucide-react';
import { useDocumentContext } from '../../context/DocumentContext';

export const PdfUpload: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const { processContent } = useDocumentContext();

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    // Only process PDF files
    if (file.type !== 'application/pdf') {
      alert('Please select a PDF file');
      return;
    }

    setFileName(file.name);
    // In a real app, we would send this to the PDF processing service
    processContent('PDF has been uploaded and is being processed for text extraction...');
  };

  const clearFile = () => {
    setFileName(null);
  };

  return (
    <div className="space-y-4">
      {!fileName ? (
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-2">Drag and drop a PDF here, or</p>
          <label className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md cursor-pointer transition-colors inline-block">
            Browse Files
            <input type="file" className="hidden" accept="application/pdf" onChange={handleFileInput} />
          </label>
          <p className="text-gray-500 text-sm mt-4">Only PDF files are supported</p>
        </div>
      ) : (
        <div className="relative bg-gray-50 p-4 rounded-lg border">
          <button
            className="absolute right-2 top-2 bg-red-600 text-white p-1 rounded-full hover:bg-red-700 transition-colors"
            onClick={clearFile}
          >
            <X className="h-4 w-4" />
          </button>
          <div className="flex items-center">
            <FileText className="h-10 w-10 text-blue-600 mr-3" />
            <div>
              <p className="font-medium text-gray-800">{fileName}</p>
              <p className="text-sm text-gray-500">PDF document ready for processing</p>
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
          <Layers className="h-4 w-4 mr-1" />
          PDF Processing Options
        </h3>
        <div className="space-y-2">
          <label className="flex items-center">
            <input type="checkbox" className="rounded text-blue-600" defaultChecked />
            <span className="ml-2 text-sm text-gray-700">Process all pages</span>
          </label>
          <div className="pl-6">
            <p className="text-xs text-gray-500 mb-1">Or specify page range:</p>
            <div className="flex items-center space-x-2">
              <input 
                type="text" 
                placeholder="e.g., 1-5, 8" 
                className="text-sm border rounded px-2 py-1 w-full" 
                disabled
              />
            </div>
          </div>
          <label className="flex items-center mt-2">
            <input type="checkbox" className="rounded text-blue-600" defaultChecked />
            <span className="ml-2 text-sm text-gray-700">Extract tables as structured data</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" className="rounded text-blue-600" defaultChecked />
            <span className="ml-2 text-sm text-gray-700">Maintain original document layout</span>
          </label>
        </div>
      </div>
    </div>
  );
};