import React from 'react';
import { useDocumentContext } from '../../context/DocumentContext';
import { Bold, Italic } from 'lucide-react';

export const HeadingStyler: React.FC = () => {
  const { documentStyle, updateDocumentStyle } = useDocumentContext();
  
  const handleHeadingColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateDocumentStyle({ ...documentStyle, headingColor: e.target.value });
  };
  
  const toggleHeadingBold = () => {
    updateDocumentStyle({ 
      ...documentStyle, 
      headingWeight: documentStyle.headingWeight === 'bold' ? 'normal' : 'bold' 
    });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm text-gray-600 mb-1">Heading Color</label>
          <div className="flex">
            <input 
              type="color" 
              className="h-10 w-10 rounded border"
              value={documentStyle.headingColor}
              onChange={handleHeadingColorChange}
            />
            <input 
              type="text" 
              className="border rounded-md ml-2 p-2 w-full"
              value={documentStyle.headingColor}
              onChange={handleHeadingColorChange}
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-gray-600 mb-1">Style</label>
          <div className="flex space-x-2">
            <button 
              className={`p-2 border rounded-md ${documentStyle.headingWeight === 'bold' ? 'bg-blue-100 border-blue-300' : 'bg-white'}`}
              onClick={toggleHeadingBold}
            >
              <Bold className="h-5 w-5" />
            </button>
            <button className="p-2 border rounded-md">
              <Italic className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
      
      <div>
        <label className="block text-sm text-gray-600 mb-1">Heading Size Scale</label>
        <input 
          type="range" 
          min="1" 
          max="5" 
          value="3" 
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500">
          <span>Smaller</span>
          <span>Default</span>
          <span>Larger</span>
        </div>
      </div>
      
      <div className="border rounded-md p-3">
        <h3 className="text-base mb-2 border-b pb-1" style={{ color: documentStyle.headingColor, fontWeight: documentStyle.headingWeight }}>Heading 3 Preview</h3>
        <h4 className="text-sm" style={{ color: documentStyle.headingColor, fontWeight: documentStyle.headingWeight }}>Heading 4 Preview</h4>
      </div>
    </div>
  );
};