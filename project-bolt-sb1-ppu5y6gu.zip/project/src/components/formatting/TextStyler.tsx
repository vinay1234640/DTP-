import React from 'react';
import { useDocumentContext } from '../../context/DocumentContext';
import { AlignLeft, AlignCenter as AlignCenterIcon, AlignRight, Bold, Italic, Underline } from 'lucide-react';

export const TextStyler: React.FC = () => {
  const { documentStyle, updateDocumentStyle } = useDocumentContext();
  
  const handleTextColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateDocumentStyle({ ...documentStyle, textColor: e.target.value });
  };
  
  const handleLineHeightChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateDocumentStyle({ ...documentStyle, lineHeight: e.target.value });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm text-gray-600 mb-1">Text Color</label>
          <div className="flex">
            <input 
              type="color" 
              className="h-10 w-10 rounded border"
              value={documentStyle.textColor}
              onChange={handleTextColorChange}
            />
            <input 
              type="text" 
              className="border rounded-md ml-2 p-2 w-full"
              value={documentStyle.textColor}
              onChange={handleTextColorChange}
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-gray-600 mb-1">Line Height</label>
          <select 
            className="w-full border rounded-md p-2 focus:ring-blue-500 focus:border-blue-500"
            value={documentStyle.lineHeight}
            onChange={handleLineHeightChange}
          >
            <option value="1">Single</option>
            <option value="1.15">1.15</option>
            <option value="1.5">1.5</option>
            <option value="2">Double</option>
          </select>
        </div>
      </div>
      
      <div>
        <label className="block text-sm text-gray-600 mb-1">Text Alignment</label>
        <div className="flex space-x-2">
          <button className="flex-1 p-2 border rounded-md bg-blue-100 border-blue-300">
            <AlignLeft className="h-5 w-5 mx-auto" />
          </button>
          <button className="flex-1 p-2 border rounded-md">
            <AlignCenterIcon className="h-5 w-5 mx-auto" />
          </button>
          <button className="flex-1 p-2 border rounded-md">
            <AlignRight className="h-5 w-5 mx-auto" />
          </button>
        </div>
      </div>
      
      <div>
        <label className="block text-sm text-gray-600 mb-1">Text Style</label>
        <div className="flex space-x-2">
          <button className="flex-1 p-2 border rounded-md">
            <Bold className="h-5 w-5 mx-auto" />
          </button>
          <button className="flex-1 p-2 border rounded-md">
            <Italic className="h-5 w-5 mx-auto" />
          </button>
          <button className="flex-1 p-2 border rounded-md">
            <Underline className="h-5 w-5 mx-auto" />
          </button>
        </div>
      </div>
      
      <div 
        className="border rounded-md p-3"
        style={{ 
          color: documentStyle.textColor,
          lineHeight: documentStyle.lineHeight,
          fontFamily: documentStyle.fontFamily
        }}
      >
        <p className="mb-2">This is a preview of the body text with your selected styling options.</p>
        <p>Notice how the line height and color settings affect readability.</p>
      </div>
    </div>
  );
};