import React from 'react';
import { useDocumentContext } from '../../context/DocumentContext';

export const FontSelector: React.FC = () => {
  const { documentStyle, updateDocumentStyle } = useDocumentContext();
  
  const handleFontChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateDocumentStyle({ ...documentStyle, fontFamily: e.target.value });
  };
  
  const handleFontSizeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateDocumentStyle({ ...documentStyle, fontSize: e.target.value });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label className="block text-sm text-gray-600 mb-1">Font Family</label>
        <select 
          className="w-full border rounded-md p-2 focus:ring-blue-500 focus:border-blue-500"
          value={documentStyle.fontFamily}
          onChange={handleFontChange}
        >
          <option value="Arial, sans-serif">Arial</option>
          <option value="'Times New Roman', serif">Times New Roman</option>
          <option value="Calibri, sans-serif">Calibri</option>
          <option value="Georgia, serif">Georgia</option>
          <option value="Verdana, sans-serif">Verdana</option>
          <option value="'Courier New', monospace">Courier New</option>
        </select>
      </div>
      
      <div>
        <label className="block text-sm text-gray-600 mb-1">Base Font Size</label>
        <select 
          className="w-full border rounded-md p-2 focus:ring-blue-500 focus:border-blue-500"
          value={documentStyle.fontSize}
          onChange={handleFontSizeChange}
        >
          <option value="10pt">10pt</option>
          <option value="11pt">11pt</option>
          <option value="12pt">12pt</option>
          <option value="14pt">14pt</option>
          <option value="16pt">16pt</option>
        </select>
      </div>
      
      <div className="col-span-1 md:col-span-2">
        <label className="block text-sm text-gray-600 mb-1">Preview</label>
        <div 
          className="border rounded-md p-3 text-center"
          style={{ 
            fontFamily: documentStyle.fontFamily,
            fontSize: documentStyle.fontSize === '10pt' ? '0.875rem' : 
                    documentStyle.fontSize === '11pt' ? '0.9375rem' : 
                    documentStyle.fontSize === '12pt' ? '1rem' : 
                    documentStyle.fontSize === '14pt' ? '1.125rem' : '1.25rem'
          }}
        >
          The quick brown fox jumps over the lazy dog.
        </div>
      </div>
    </div>
  );
};