import React from 'react';
import { useDocumentContext } from '../../context/DocumentContext';
import { FontSelector } from './FontSelector';
import { HeadingStyler } from './HeadingStyler';
import { TextStyler } from './TextStyler';
import { CopyleftIcon as FontStyle, Type, List, AlignCenter } from 'lucide-react';

export const FormattingControls: React.FC = () => {
  const { documentStyle, updateDocumentStyle } = useDocumentContext();

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-800">Document Formatting</h2>
      
      <div className="space-y-6">
        <section className="space-y-3">
          <h3 className="text-sm font-medium text-gray-700 flex items-center">
            <FontStyle className="h-4 w-4 mr-1" />
            Font Selection
          </h3>
          <FontSelector />
        </section>
        
        <section className="space-y-3">
          <h3 className="text-sm font-medium text-gray-700 flex items-center">
            <Type className="h-4 w-4 mr-1" />
            Heading Styles
          </h3>
          <HeadingStyler />
        </section>
        
        <section className="space-y-3">
          <h3 className="text-sm font-medium text-gray-700 flex items-center">
            <AlignCenter className="h-4 w-4 mr-1" />
            Body Text Styles
          </h3>
          <TextStyler />
        </section>
        
        <section className="space-y-3">
          <h3 className="text-sm font-medium text-gray-700 flex items-center">
            <List className="h-4 w-4 mr-1" />
            List Formatting
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-600 mb-1">Bullet Lists</label>
              <select className="w-full border rounded-md p-2 focus:ring-blue-500 focus:border-blue-500">
                <option>● Circle</option>
                <option>■ Square</option>
                <option>▶ Triangle</option>
                <option>- Dash</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Numbered Lists</label>
              <select className="w-full border rounded-md p-2 focus:ring-blue-500 focus:border-blue-500">
                <option>1, 2, 3</option>
                <option>A, B, C</option>
                <option>i, ii, iii</option>
                <option>I, II, III</option>
              </select>
            </div>
          </div>
        </section>
      </div>
      
      <div className="border-t pt-4 mt-6">
        <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md transition-colors">
          Apply Formatting
        </button>
      </div>
    </div>
  );
};