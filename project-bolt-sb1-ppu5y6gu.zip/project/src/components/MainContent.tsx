import React, { useState } from 'react';
import { InputSection } from './input/InputSection';
import { FormattingControls } from './formatting/FormattingControls';
import { PreviewPane } from './preview/PreviewPane';
import { ExportOptions } from './export/ExportOptions';

export const MainContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'input' | 'format' | 'export'>('input');

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="border-b">
        <div className="flex">
          <button
            className={`px-6 py-3 font-medium ${
              activeTab === 'input'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('input')}
          >
            Input
          </button>
          <button
            className={`px-6 py-3 font-medium ${
              activeTab === 'format'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('format')}
          >
            Format
          </button>
          <button
            className={`px-6 py-3 font-medium ${
              activeTab === 'export'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('export')}
          >
            Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 lg:gap-6">
        <div className="p-6">
          {activeTab === 'input' && <InputSection />}
          {activeTab === 'format' && <FormattingControls />}
          {activeTab === 'export' && <ExportOptions />}
        </div>
        <div className="p-6 border-t lg:border-t-0 lg:border-l">
          <PreviewPane />
        </div>
      </div>
    </div>
  );
};