import React from 'react';
import { FileText, Settings } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileText className="h-8 w-8 text-blue-600" />
          <h1 className="text-xl font-bold text-gray-800">TextTract</h1>
        </div>
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Home</a>
          <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Features</a>
          <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Pricing</a>
          <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Help</a>
        </nav>
        <div className="flex items-center space-x-4">
          <button className="p-2 text-gray-500 hover:text-blue-600 transition-colors">
            <Settings className="h-5 w-5" />
          </button>
          <button className="hidden md:block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors">
            Get Started
          </button>
        </div>
      </div>
    </header>
  );
};