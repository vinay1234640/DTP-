import React from 'react';
import { Layout } from './components/Layout';
import { DocumentProvider } from './context/DocumentContext';
import { MainContent } from './components/MainContent';

function App() {
  return (
    <DocumentProvider>
      <Layout>
        <MainContent />
      </Layout>
    </DocumentProvider>
  );
}

export default App;