import React, { createContext, useContext, useState, ReactNode } from 'react';

interface DocumentStyle {
  fontFamily: string;
  fontSize: string;
  headingColor: string;
  headingWeight: 'normal' | 'bold';
  textColor: string;
  lineHeight: string;
}

interface DocumentContextType {
  documentContent: string;
  documentStyle: DocumentStyle;
  isEditing: boolean;
  processContent: (content: string) => void;
  updateDocumentStyle: (style: DocumentStyle) => void;
  setIsEditing: (value: boolean) => void;
}

const defaultStyle: DocumentStyle = {
  fontFamily: 'Arial, sans-serif',
  fontSize: '12pt',
  headingColor: '#333333',
  headingWeight: 'bold',
  textColor: '#000000',
  lineHeight: '1.5',
};

const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

export const DocumentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [documentContent, setDocumentContent] = useState<string>('');
  const [documentStyle, setDocumentStyle] = useState<DocumentStyle>(defaultStyle);
  const [isEditing, setIsEditing] = useState<boolean>(false);

  const processContent = (content: string) => {
    setDocumentContent(content);
  };

  const updateDocumentStyle = (style: DocumentStyle) => {
    setDocumentStyle(style);
  };

  return (
    <DocumentContext.Provider
      value={{
        documentContent,
        documentStyle,
        isEditing,
        processContent,
        updateDocumentStyle,
        setIsEditing,
      }}
    >
      {children}
    </DocumentContext.Provider>
  );
};

export const useDocumentContext = (): DocumentContextType => {
  const context = useContext(DocumentContext);
  if (context === undefined) {
    throw new Error('useDocumentContext must be used within a DocumentProvider');
  }
  return context;
};